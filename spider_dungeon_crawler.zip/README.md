# Spider Dungeon Crawler
Final Project for Intro to game development class.

###Team
Elliot Simpson - Jsimps72@uncc.edu  
Bates Jernigan - tjerniga@uncc.edu  
Elizabeth Theuamthalaray - etheuamt@uncc.edu  
Davy Pushard - dpushard@uncc.edu  

###Overview
A dungeon crawler with a spider protagonist. The spider travels through randomly generated areas, gaining abilities  
enhancements, in an effort to find the perfect home. 
