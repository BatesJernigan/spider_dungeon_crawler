﻿#pragma strict

public var destinationRoom : int; //The roomID of the destination room

//Create an enum to represent direction
enum Direction {North, East, South, West}

public var portalDirection : Direction; //Which direction does the portal lead?
